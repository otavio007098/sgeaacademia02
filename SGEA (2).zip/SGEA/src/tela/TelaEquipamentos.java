package tela;

import dao.CategoriaDao;
import dao.EquipamentoDao;
import modelo.Categoria;
import modelo.Equipamento;
import modelo.Util;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.time.LocalDate;

public class TelaEquipamentos extends Frame implements ActionListener, ItemListener {
    private EquipamentoDao dao = new EquipamentoDao();
    private java.util.List<Categoria> categorias = new CategoriaDao().listar();
    private java.util.List<Equipamento> equipamentos;
    private List lista = new List(15);
    private TextField campoBusca = new TextField(15);
    private TextField campoNome = new TextField(20);
    private TextField campoMarca = new TextField(20);
    private TextField campoQuantidade = new TextField(20);
    private TextField campoData = new TextField(20);
    private TextField campoLocal = new TextField(20);
    private Choice comboEstado = new Choice();
    private Choice comboCategoria = new Choice();
    private Equipamento selecionado;

    public TelaEquipamentos() {
        super("Equipamentos");
        setLayout(new BorderLayout(10, 10));

        for (String estado : Equipamento.ESTADOS) {
            comboEstado.add(estado);
        }
        for (Categoria c : categorias) {
            comboCategoria.add(c.getNome());
        }

        Panel busca = new Panel();
        Button buscar = new Button("Buscar");
        Button todos = new Button("Todos");
        busca.add(new Label("Nome:"));
        busca.add(campoBusca);
        busca.add(buscar);
        busca.add(todos);

        Panel esquerda = new Panel(new BorderLayout(5, 5));
        esquerda.add(busca, BorderLayout.NORTH);
        esquerda.add(lista, BorderLayout.CENTER);

        Panel form = new Panel(new GridLayout(0, 2, 5, 5));
        form.add(new Label("Nome"));
        form.add(campoNome);
        form.add(new Label("Marca"));
        form.add(campoMarca);
        form.add(new Label("Quantidade"));
        form.add(campoQuantidade);
        form.add(new Label("Aquisição (dd/MM/aaaa)"));
        form.add(campoData);
        form.add(new Label("Estado"));
        form.add(comboEstado);
        form.add(new Label("Localização"));
        form.add(campoLocal);
        form.add(new Label("Categoria"));
        form.add(comboCategoria);

        Button novo = new Button("Novo");
        Button salvar = new Button("Salvar");
        Button excluir = new Button("Excluir");
        Button manutencoes = new Button("Manutenções");
        Panel botoes = new Panel(new GridLayout(1, 4, 5, 5));
        botoes.add(novo);
        botoes.add(salvar);
        botoes.add(excluir);
        botoes.add(manutencoes);

        Panel direita = new Panel(new BorderLayout(5, 5));
        direita.add(form, BorderLayout.NORTH);
        direita.add(botoes, BorderLayout.SOUTH);

        add(esquerda, BorderLayout.CENTER);
        add(direita, BorderLayout.EAST);

        lista.addItemListener(this);
        buscar.addActionListener(this);
        todos.addActionListener(this);
        novo.addActionListener(this);
        salvar.addActionListener(this);
        excluir.addActionListener(this);
        manutencoes.addActionListener(this);

        Aviso.fecharAoSair(this, false);
        carregar(dao.listar());
        setSize(820, 420);
        setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        if (comando.equals("Buscar")) {
            carregar(dao.buscarPorNome(campoBusca.getText().trim()));
        } else if (comando.equals("Todos")) {
            campoBusca.setText("");
            carregar(dao.listar());
        } else if (comando.equals("Novo")) {
            limpar();
        } else if (comando.equals("Salvar")) {
            salvar();
        } else if (comando.equals("Excluir")) {
            excluir();
        } else if (comando.equals("Manutenções")) {
            abrirManutencoes();
        }
    }

    public void itemStateChanged(ItemEvent e) {
        if (lista.getSelectedIndex() >= 0) {
            selecionar();
        }
    }

    private void carregar(java.util.List<Equipamento> dados) {
        equipamentos = dados;
        lista.removeAll();
        for (Equipamento e : equipamentos) {
            lista.add(e.toString());
        }
    }

    private void selecionar() {
        selecionado = equipamentos.get(lista.getSelectedIndex());
        campoNome.setText(selecionado.getNome());
        campoMarca.setText(selecionado.getMarca());
        campoQuantidade.setText(String.valueOf(selecionado.getQuantidade()));
        campoData.setText(Util.formatar(selecionado.getDataAquisicao()));
        campoLocal.setText(selecionado.getLocalizacao());
        comboEstado.select(selecionado.getEstado());
        for (int i = 0; i < categorias.size(); i++) {
            if (categorias.get(i).getId() == selecionado.getCategoriaId()) {
                comboCategoria.select(i);
            }
        }
    }

    private void limpar() {
        selecionado = null;
        campoNome.setText("");
        campoMarca.setText("");
        campoQuantidade.setText("");
        campoData.setText("");
        campoLocal.setText("");
        comboEstado.select(0);
        if (categorias.size() > 0) {
            comboCategoria.select(0);
        }
    }

    private void salvar() {
        if (categorias.isEmpty()) {
            Aviso.mostrar(this, "Atenção", "Cadastre uma categoria antes.");
            return;
        }
        String nome = campoNome.getText().trim();
        if (nome.isEmpty()) {
            Aviso.mostrar(this, "Atenção", "Informe o nome.");
            return;
        }
        int quantidade;
        LocalDate data;
        try {
            quantidade = Integer.parseInt(campoQuantidade.getText().trim());
            if (quantidade < 1) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            Aviso.mostrar(this, "Atenção", "Quantidade inválida.");
            return;
        }
        try {
            data = Util.converter(campoData.getText());
        } catch (Exception e) {
            Aviso.mostrar(this, "Atenção", "Data inválida. Use dd/MM/aaaa.");
            return;
        }
        int categoriaId = categorias.get(comboCategoria.getSelectedIndex()).getId();
        if (selecionado == null) {
            selecionado = new Equipamento(0, nome, campoMarca.getText(), quantidade, data,
                    comboEstado.getSelectedItem(), campoLocal.getText(), categoriaId);
        } else {
            selecionado.setNome(nome);
            selecionado.setMarca(campoMarca.getText());
            selecionado.setQuantidade(quantidade);
            selecionado.setDataAquisicao(data);
            selecionado.setEstado(comboEstado.getSelectedItem());
            selecionado.setLocalizacao(campoLocal.getText());
            selecionado.setCategoriaId(categoriaId);
        }
        dao.salvar(selecionado);
        limpar();
        carregar(dao.listar());
    }

    private void excluir() {
        if (selecionado == null) {
            Aviso.mostrar(this, "Atenção", "Selecione um equipamento.");
            return;
        }
        dao.excluir(selecionado.getId());
        limpar();
        carregar(dao.listar());
    }

    private void abrirManutencoes() {
        if (selecionado == null) {
            Aviso.mostrar(this, "Atenção", "Selecione um equipamento.");
            return;
        }
        new TelaManutencoes(selecionado).setVisible(true);
    }
}
