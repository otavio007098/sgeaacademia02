package tela;

import dao.CategoriaDao;
import dao.EquipamentoDao;
import modelo.Categoria;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class TelaCategorias extends Frame implements ActionListener, ItemListener {
    private CategoriaDao dao = new CategoriaDao();
    private java.util.List<Categoria> categorias;
    private List lista = new List(10);
    private TextField campoNome = new TextField(20);
    private Label modo = new Label();
    private Categoria selecionada;

    public TelaCategorias() {
        super("Categorias");
        setLayout(new BorderLayout(10, 10));

        Panel form = new Panel(new GridLayout(0, 1, 5, 5));
        Button novo = new Button("Novo");
        Button salvar = new Button("Salvar");
        Button excluir = new Button("Excluir");
        form.add(modo);
        form.add(new Label("Nome da categoria"));
        form.add(campoNome);
        form.add(novo);
        form.add(salvar);
        form.add(excluir);

        add(lista, BorderLayout.CENTER);
        add(form, BorderLayout.EAST);

        lista.addItemListener(this);
        novo.addActionListener(this);
        salvar.addActionListener(this);
        excluir.addActionListener(this);

        Aviso.fecharAoSair(this, false);
        carregar();
        limpar();
        setSize(500, 340);
        setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        if (comando.equals("Novo")) {
            limpar();
        } else if (comando.equals("Salvar")) {
            salvar();
        } else if (comando.equals("Excluir")) {
            excluir();
        }
    }

    public void itemStateChanged(ItemEvent e) {
        int i = lista.getSelectedIndex();
        if (i >= 0) {
            selecionada = categorias.get(i);
            campoNome.setText(selecionada.getNome());
            modo.setText("Editando: " + selecionada.getNome());
        }
    }

    private void carregar() {
        categorias = dao.listar();
        lista.removeAll();
        for (Categoria c : categorias) {
            lista.add(c.getNome());
        }
    }

    private void limpar() {
        selecionada = null;
        campoNome.setText("");
        modo.setText("Nova categoria");
        if (lista.getSelectedIndex() >= 0) {
            lista.deselect(lista.getSelectedIndex());
        }
    }

    private void salvar() {
        String nome = campoNome.getText().trim();
        if (nome.isEmpty()) {
            Aviso.mostrar(this, "Atenção", "Informe o nome da categoria.");
            return;
        }
        if (selecionada == null) {
            selecionada = new Categoria(0, nome);
        } else {
            selecionada.setNome(nome);
        }
        dao.salvar(selecionada);
        limpar();
        carregar();
    }

    private void excluir() {
        if (selecionada == null) {
            Aviso.mostrar(this, "Atenção", "Selecione uma categoria.");
            return;
        }
        if (new EquipamentoDao().existeCategoria(selecionada.getId())) {
            Aviso.mostrar(this, "Atenção", "Existem equipamentos nessa categoria.");
            return;
        }
        dao.excluir(selecionada.getId());
        limpar();
        carregar();
    }
}
