package tela;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Aviso {

    public static void mostrar(Frame dono, String titulo, String mensagem) {
        Dialog dialogo = new Dialog(dono, titulo, true);
        dialogo.setLayout(new BorderLayout(10, 10));
        TextArea texto = new TextArea(mensagem, Math.min(12, mensagem.split("\n").length + 1), 50,
                TextArea.SCROLLBARS_VERTICAL_ONLY);
        texto.setEditable(false);
        Button ok = new Button("OK");
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialogo.dispose();
            }
        });
        java.awt.Panel rodape = new java.awt.Panel(new FlowLayout());
        rodape.add(ok);
        dialogo.add(new Label(" "), BorderLayout.NORTH);
        dialogo.add(texto, BorderLayout.CENTER);
        dialogo.add(rodape, BorderLayout.SOUTH);
        dialogo.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dialogo.dispose();
            }
        });
        dialogo.pack();
        dialogo.setLocationRelativeTo(dono);
        dialogo.setVisible(true);
    }

    public static void fecharAoSair(Frame frame, boolean encerrar) {
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (encerrar) {
                    System.exit(0);
                }
                frame.dispose();
            }
        });
    }
}
