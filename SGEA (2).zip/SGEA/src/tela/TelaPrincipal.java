package tela;

import dao.EquipamentoDao;
import dao.ManutencaoDao;
import modelo.Equipamento;
import modelo.Manutencao;
import modelo.Util;

import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

public class TelaPrincipal extends Frame implements ActionListener {

    public TelaPrincipal() {
        super("SGEA - Gerenciamento de Equipamentos de Academia");
        setLayout(new GridLayout(5, 1, 10, 10));

        Button equipamentos = new Button("Equipamentos");
        Button categorias = new Button("Categorias");
        Button relatorios = new Button("Relatórios");
        Button sair = new Button("Sair");

        equipamentos.addActionListener(this);
        categorias.addActionListener(this);
        relatorios.addActionListener(this);
        sair.addActionListener(this);

        Panel titulo = new Panel();
        titulo.add(new Label("SGEA"));
        add(titulo);
        add(equipamentos);
        add(categorias);
        add(relatorios);
        add(sair);

        Aviso.fecharAoSair(this, true);
        setSize(360, 320);
        setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        if (comando.equals("Equipamentos")) {
            new TelaEquipamentos().setVisible(true);
        } else if (comando.equals("Categorias")) {
            new TelaCategorias().setVisible(true);
        } else if (comando.equals("Relatórios")) {
            new TelaRelatorios().setVisible(true);
        } else if (comando.equals("Sair")) {
            System.exit(0);
        }
    }

    public void notificarManutencoes() {
        String texto = precisamManutencao();
        if (!texto.isEmpty()) {
            Aviso.mostrar(this, "Manutenção necessária", texto);
        }
    }

    static String precisamManutencao() {
        EquipamentoDao equipamentoDao = new EquipamentoDao();
        StringBuilder texto = new StringBuilder();
        for (Equipamento e : equipamentoDao.listarComProblema()) {
            texto.append(e.getNome()).append(" - ").append(e.getEstado()).append("\n");
        }
        for (Manutencao m : new ManutencaoDao().listarAgendadasAte(LocalDate.now())) {
            Equipamento e = equipamentoDao.buscarPorId(m.getEquipamentoId());
            if (e != null) {
                texto.append(e.getNome()).append(" - manutenção agendada para ")
                        .append(Util.formatar(m.getData())).append("\n");
            }
        }
        return texto.toString();
    }

    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
        tela.notificarManutencoes();
    }
}
