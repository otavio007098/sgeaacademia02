package tela;

import dao.CategoriaDao;
import dao.EquipamentoDao;
import modelo.Categoria;
import modelo.Equipamento;
import modelo.Util;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaRelatorios extends Frame implements ActionListener {
    private Choice comboRelatorio = new Choice();
    private TextArea saida = new TextArea();

    public TelaRelatorios() {
        super("Relatórios");
        setLayout(new BorderLayout(10, 10));

        comboRelatorio.add("Equipamentos em manutenção");
        comboRelatorio.add("Equipamentos disponíveis para uso");
        comboRelatorio.add("Precisam de manutenção");
        comboRelatorio.add("Relatório geral");
        Button gerar = new Button("Gerar");

        Panel topo = new Panel();
        topo.add(new Label("Relatório:"));
        topo.add(comboRelatorio);
        topo.add(gerar);

        saida.setEditable(false);
        saida.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        add(topo, BorderLayout.NORTH);
        add(saida, BorderLayout.CENTER);

        gerar.addActionListener(this);

        Aviso.fecharAoSair(this, false);
        setSize(750, 450);
        setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        gerar();
    }

    private void gerar() {
        EquipamentoDao dao = new EquipamentoDao();
        switch (comboRelatorio.getSelectedIndex()) {
            case 0:
                saida.setText(montar(dao.listarPorEstado("Manutenção")));
                break;
            case 1:
                saida.setText(montar(dao.listarDisponiveis()));
                break;
            case 2:
                String texto = TelaPrincipal.precisamManutencao();
                if (texto.isEmpty()) {
                    saida.setText("Nenhum equipamento precisa de manutenção.");
                } else {
                    saida.setText(texto);
                }
                break;
            default:
                saida.setText(montar(dao.listar()));
        }
    }

    private String montar(java.util.List<Equipamento> equipamentos) {
        if (equipamentos.isEmpty()) {
            return "Nenhum equipamento encontrado.";
        }
        CategoriaDao categoriaDao = new CategoriaDao();
        StringBuilder texto = new StringBuilder();
        int total = 0;
        for (Equipamento e : equipamentos) {
            Categoria c = categoriaDao.buscarPorId(e.getCategoriaId());
            String nomeCategoria = "-";
            if (c != null) {
                nomeCategoria = c.getNome();
            }
            texto.append(e.getNome()).append(" | ").append(e.getMarca())
                    .append(" | qtd: ").append(e.getQuantidade())
                    .append(" | ").append(e.getEstado())
                    .append(" | ").append(e.getLocalizacao())
                    .append(" | ").append(nomeCategoria)
                    .append(" | adquirido em ").append(Util.formatar(e.getDataAquisicao()))
                    .append("\n");
            total += e.getQuantidade();
        }
        texto.append("\nTotal de itens: ").append(total);
        return texto.toString();
    }
}
