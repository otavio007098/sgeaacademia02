package tela;

import dao.ManutencaoDao;
import modelo.Equipamento;
import modelo.Manutencao;
import modelo.Util;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.time.LocalDate;

public class TelaManutencoes extends Frame implements ActionListener, ItemListener {
    private ManutencaoDao dao = new ManutencaoDao();
    private Equipamento equipamento;
    private java.util.List<Manutencao> manutencoes;
    private List lista = new List(12);
    private TextField campoData = new TextField(20);
    private TextField campoDescricao = new TextField(20);
    private TextField campoResponsavel = new TextField(20);
    private Choice comboTipo = new Choice();
    private Manutencao selecionada;

    public TelaManutencoes(Equipamento equipamento) {
        super("Manutenções - " + equipamento.getNome());
        this.equipamento = equipamento;
        setLayout(new BorderLayout(10, 10));

        comboTipo.add("Realizada");
        comboTipo.add("Agendada");

        Panel form = new Panel(new GridLayout(0, 2, 5, 5));
        form.add(new Label("Data (dd/MM/aaaa)"));
        form.add(campoData);
        form.add(new Label("Descrição"));
        form.add(campoDescricao);
        form.add(new Label("Responsável"));
        form.add(campoResponsavel);
        form.add(new Label("Tipo"));
        form.add(comboTipo);

        Button novo = new Button("Novo");
        Button salvar = new Button("Salvar");
        Button excluir = new Button("Excluir");
        Panel botoes = new Panel(new GridLayout(1, 3, 5, 5));
        botoes.add(novo);
        botoes.add(salvar);
        botoes.add(excluir);

        Panel direita = new Panel(new BorderLayout(5, 5));
        direita.add(form, BorderLayout.NORTH);
        direita.add(botoes, BorderLayout.SOUTH);

        add(new Label("Histórico de manutenção"), BorderLayout.NORTH);
        add(lista, BorderLayout.CENTER);
        add(direita, BorderLayout.EAST);

        lista.addItemListener(this);
        novo.addActionListener(this);
        salvar.addActionListener(this);
        excluir.addActionListener(this);

        Aviso.fecharAoSair(this, false);
        carregar();
        setSize(800, 380);
        setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        if (comando.equals("Novo")) {
            limpar();
        } else if (comando.equals("Salvar")) {
            salvar();
        } else if (comando.equals("Excluir")) {
            excluir();
        }
    }

    public void itemStateChanged(ItemEvent e) {
        if (lista.getSelectedIndex() >= 0) {
            selecionar();
        }
    }

    private void carregar() {
        manutencoes = dao.listarPorEquipamento(equipamento.getId());
        lista.removeAll();
        for (Manutencao m : manutencoes) {
            lista.add(m.toString() + " (" + m.getResponsavel() + ")");
        }
    }

    private void selecionar() {
        selecionada = manutencoes.get(lista.getSelectedIndex());
        campoData.setText(Util.formatar(selecionada.getData()));
        campoDescricao.setText(selecionada.getDescricao());
        campoResponsavel.setText(selecionada.getResponsavel());
        if (selecionada.isRealizada()) {
            comboTipo.select(0);
        } else {
            comboTipo.select(1);
        }
    }

    private void limpar() {
        selecionada = null;
        campoData.setText("");
        campoDescricao.setText("");
        campoResponsavel.setText("");
        comboTipo.select(0);
    }

    private void salvar() {
        LocalDate data;
        try {
            data = Util.converter(campoData.getText());
        } catch (Exception e) {
            Aviso.mostrar(this, "Atenção", "Data inválida. Use dd/MM/aaaa.");
            return;
        }
        if (campoDescricao.getText().trim().isEmpty() || campoResponsavel.getText().trim().isEmpty()) {
            Aviso.mostrar(this, "Atenção", "Informe a descrição e o responsável.");
            return;
        }
        boolean realizada = comboTipo.getSelectedIndex() == 0;
        if (selecionada == null) {
            selecionada = new Manutencao(0, equipamento.getId(), data, campoDescricao.getText(),
                    campoResponsavel.getText(), realizada);
        } else {
            selecionada.setData(data);
            selecionada.setDescricao(campoDescricao.getText());
            selecionada.setResponsavel(campoResponsavel.getText());
            selecionada.setRealizada(realizada);
        }
        dao.salvar(selecionada);
        limpar();
        carregar();
    }

    private void excluir() {
        if (selecionada == null) {
            Aviso.mostrar(this, "Atenção", "Selecione uma manutenção.");
            return;
        }
        dao.excluir(selecionada.getId());
        limpar();
        carregar();
    }
}
