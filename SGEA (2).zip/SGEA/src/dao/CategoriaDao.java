package dao;

import modelo.Categoria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDao {

    public List<Categoria> listar() {
        List<Categoria> lista = new ArrayList<>();
        try (Connection c = Conexao.abrir();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery("SELECT id, nome FROM categoria ORDER BY nome")) {
            while (r.next()) {
                lista.add(new Categoria(r.getInt("id"), r.getString("nome")));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    public Categoria buscarPorId(int id) {
        try (Connection c = Conexao.abrir();
             PreparedStatement p = c.prepareStatement("SELECT id, nome FROM categoria WHERE id = ?")) {
            p.setInt(1, id);
            try (ResultSet r = p.executeQuery()) {
                if (r.next()) {
                    return new Categoria(r.getInt("id"), r.getString("nome"));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public void salvar(Categoria categoria) {
        try (Connection c = Conexao.abrir()) {
            if (categoria.getId() == 0) {
                try (PreparedStatement p = c.prepareStatement("INSERT INTO categoria (nome) VALUES (?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    p.setString(1, categoria.getNome());
                    p.executeUpdate();
                    try (ResultSet r = p.getGeneratedKeys()) {
                        if (r.next()) {
                            categoria.setId(r.getInt(1));
                        }
                    }
                }
            } else {
                try (PreparedStatement p = c.prepareStatement("UPDATE categoria SET nome = ? WHERE id = ?")) {
                    p.setString(1, categoria.getNome());
                    p.setInt(2, categoria.getId());
                    p.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void excluir(int id) {
        try (Connection c = Conexao.abrir();
             PreparedStatement p = c.prepareStatement("DELETE FROM categoria WHERE id = ?")) {
            p.setInt(1, id);
            p.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
