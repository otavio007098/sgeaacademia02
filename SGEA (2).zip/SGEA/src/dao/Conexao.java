package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexao {
    private static final String URL = "jdbc:sqlite:sgea.db";
    private static boolean criado = false;

    static Connection abrir() throws SQLException {
        Connection c = DriverManager.getConnection(URL);
        try (Statement s = c.createStatement()) {
            s.execute("PRAGMA foreign_keys = ON");
            if (!criado) {
                s.execute("CREATE TABLE IF NOT EXISTS categoria ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL)");
                s.execute("CREATE TABLE IF NOT EXISTS equipamento ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, marca TEXT, "
                        + "quantidade INTEGER NOT NULL, data_aquisicao TEXT NOT NULL, estado TEXT NOT NULL, "
                        + "localizacao TEXT, categoria_id INTEGER NOT NULL REFERENCES categoria(id))");
                s.execute("CREATE TABLE IF NOT EXISTS manutencao ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "equipamento_id INTEGER NOT NULL REFERENCES equipamento(id) ON DELETE CASCADE, "
                        + "data TEXT NOT NULL, descricao TEXT, responsavel TEXT, realizada INTEGER NOT NULL)");
                criado = true;
            }
        }
        return c;
    }
}
