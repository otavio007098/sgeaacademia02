package dao;

import modelo.Manutencao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ManutencaoDao {
    private static final String SELECT = "SELECT id, equipamento_id, data, descricao, responsavel, realizada "
            + "FROM manutencao";

    public List<Manutencao> listarPorEquipamento(int equipamentoId) {
        return consultar(SELECT + " WHERE equipamento_id = ? ORDER BY data DESC", String.valueOf(equipamentoId));
    }

    public List<Manutencao> listarAgendadasAte(LocalDate limite) {
        return consultar(SELECT + " WHERE realizada = 0 AND data <= ? ORDER BY data", limite.toString());
    }

    public void salvar(Manutencao m) {
        try (Connection c = Conexao.abrir()) {
            if (m.getId() == 0) {
                try (PreparedStatement p = c.prepareStatement("INSERT INTO manutencao (equipamento_id, data, "
                        + "descricao, responsavel, realizada) VALUES (?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    preencher(p, m);
                    p.executeUpdate();
                    try (ResultSet r = p.getGeneratedKeys()) {
                        if (r.next()) {
                            m.setId(r.getInt(1));
                        }
                    }
                }
            } else {
                try (PreparedStatement p = c.prepareStatement("UPDATE manutencao SET equipamento_id = ?, data = ?, "
                        + "descricao = ?, responsavel = ?, realizada = ? WHERE id = ?")) {
                    preencher(p, m);
                    p.setInt(6, m.getId());
                    p.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void excluir(int id) {
        try (Connection c = Conexao.abrir();
             PreparedStatement p = c.prepareStatement("DELETE FROM manutencao WHERE id = ?")) {
            p.setInt(1, id);
            p.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void preencher(PreparedStatement p, Manutencao m) throws SQLException {
        p.setInt(1, m.getEquipamentoId());
        p.setString(2, m.getData().toString());
        p.setString(3, m.getDescricao());
        p.setString(4, m.getResponsavel());
        if (m.isRealizada()) {
            p.setInt(5, 1);
        } else {
            p.setInt(5, 0);
        }
    }

    private List<Manutencao> consultar(String sql, String parametro) {
        List<Manutencao> lista = new ArrayList<>();
        try (Connection c = Conexao.abrir(); PreparedStatement p = c.prepareStatement(sql)) {
            if (parametro != null) {
                p.setString(1, parametro);
            }
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    lista.add(new Manutencao(r.getInt("id"), r.getInt("equipamento_id"),
                            LocalDate.parse(r.getString("data")), r.getString("descricao"),
                            r.getString("responsavel"), r.getInt("realizada") == 1));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }
}
