package dao;

import modelo.Equipamento;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EquipamentoDao {
    private static final String SELECT = "SELECT id, nome, marca, quantidade, data_aquisicao, estado, "
            + "localizacao, categoria_id FROM equipamento";

    public List<Equipamento> listar() {
        return consultar(SELECT + " ORDER BY nome", null);
    }

    public List<Equipamento> buscarPorNome(String texto) {
        return consultar(SELECT + " WHERE nome LIKE ? ORDER BY nome", "%" + texto + "%");
    }

    public List<Equipamento> listarPorEstado(String estado) {
        return consultar(SELECT + " WHERE estado = ? ORDER BY nome", estado);
    }

    public List<Equipamento> listarDisponiveis() {
        return consultar(SELECT + " WHERE estado = 'Novo' OR estado = 'Bom' ORDER BY nome", null);
    }

    public List<Equipamento> listarComProblema() {
        return consultar(SELECT + " WHERE estado = 'Manutenção' OR estado = 'Quebrado' ORDER BY nome", null);
    }

    public Equipamento buscarPorId(int id) {
        List<Equipamento> lista = consultar(SELECT + " WHERE id = ?", String.valueOf(id));
        if (lista.isEmpty()) {
            return null;
        }
        return lista.get(0);
    }

    public boolean existeCategoria(int categoriaId) {
        return !consultar(SELECT + " WHERE categoria_id = ?", String.valueOf(categoriaId)).isEmpty();
    }

    public void salvar(Equipamento e) {
        try (Connection c = Conexao.abrir()) {
            if (e.getId() == 0) {
                try (PreparedStatement p = c.prepareStatement("INSERT INTO equipamento (nome, marca, quantidade, "
                        + "data_aquisicao, estado, localizacao, categoria_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    preencher(p, e);
                    p.executeUpdate();
                    try (ResultSet r = p.getGeneratedKeys()) {
                        if (r.next()) {
                            e.setId(r.getInt(1));
                        }
                    }
                }
            } else {
                try (PreparedStatement p = c.prepareStatement("UPDATE equipamento SET nome = ?, marca = ?, "
                        + "quantidade = ?, data_aquisicao = ?, estado = ?, localizacao = ?, categoria_id = ? "
                        + "WHERE id = ?")) {
                    preencher(p, e);
                    p.setInt(8, e.getId());
                    p.executeUpdate();
                }
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void excluir(int id) {
        try (Connection c = Conexao.abrir();
             PreparedStatement p = c.prepareStatement("DELETE FROM equipamento WHERE id = ?")) {
            p.setInt(1, id);
            p.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void preencher(PreparedStatement p, Equipamento e) throws SQLException {
        p.setString(1, e.getNome());
        p.setString(2, e.getMarca());
        p.setInt(3, e.getQuantidade());
        p.setString(4, e.getDataAquisicao().toString());
        p.setString(5, e.getEstado());
        p.setString(6, e.getLocalizacao());
        p.setInt(7, e.getCategoriaId());
    }

    private List<Equipamento> consultar(String sql, String parametro) {
        List<Equipamento> lista = new ArrayList<>();
        try (Connection c = Conexao.abrir(); PreparedStatement p = c.prepareStatement(sql)) {
            if (parametro != null) {
                p.setString(1, parametro);
            }
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    lista.add(new Equipamento(r.getInt("id"), r.getString("nome"), r.getString("marca"),
                            r.getInt("quantidade"), LocalDate.parse(r.getString("data_aquisicao")),
                            r.getString("estado"), r.getString("localizacao"), r.getInt("categoria_id")));
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return lista;
    }
}
