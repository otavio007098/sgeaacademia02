/**
 * 
 */
/**
 * 
 */
module SGEA {
	requires java.sql;
	
	requires java.desktop;
}