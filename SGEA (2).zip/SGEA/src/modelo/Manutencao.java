package modelo;

import java.time.LocalDate;

public class Manutencao {
    private int id;
    private int equipamentoId;
    private LocalDate data;
    private String descricao;
    private String responsavel;
    private boolean realizada;

    public Manutencao(int id, int equipamentoId, LocalDate data, String descricao,
                      String responsavel, boolean realizada) {
        this.id = id;
        this.equipamentoId = equipamentoId;
        this.data = data;
        this.descricao = descricao;
        this.responsavel = responsavel;
        this.realizada = realizada;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getEquipamentoId() { return equipamentoId; }
    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getResponsavel() { return responsavel; }
    public void setResponsavel(String responsavel) { this.responsavel = responsavel; }
    public boolean isRealizada() { return realizada; }
    public void setRealizada(boolean realizada) { this.realizada = realizada; }

    public String toString() {
        String tipo = "Agendada";
        if (realizada) {
            tipo = "Realizada";
        }
        return Util.formatar(data) + " - " + tipo + " - " + descricao;
    }
}
