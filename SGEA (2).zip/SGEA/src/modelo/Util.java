package modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Util {
    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static String formatar(LocalDate data) {
        if (data == null) {
            return "";
        }
        return data.format(FORMATO);
    }

    public static LocalDate converter(String texto) {
        return LocalDate.parse(texto.trim(), FORMATO);
    }
}
