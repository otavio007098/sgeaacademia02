package modelo;

import java.time.LocalDate;

public class Equipamento {
    public static final String[] ESTADOS = {"Novo", "Bom", "Manutenção", "Quebrado"};

    private int id;
    private String nome;
    private String marca;
    private int quantidade;
    private LocalDate dataAquisicao;
    private String estado;
    private String localizacao;
    private int categoriaId;

    public Equipamento(int id, String nome, String marca, int quantidade, LocalDate dataAquisicao,
                       String estado, String localizacao, int categoriaId) {
        this.id = id;
        this.nome = nome;
        this.marca = marca;
        this.quantidade = quantidade;
        this.dataAquisicao = dataAquisicao;
        this.estado = estado;
        this.localizacao = localizacao;
        this.categoriaId = categoriaId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public LocalDate getDataAquisicao() { return dataAquisicao; }
    public void setDataAquisicao(LocalDate dataAquisicao) { this.dataAquisicao = dataAquisicao; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getLocalizacao() { return localizacao; }
    public void setLocalizacao(String localizacao) { this.localizacao = localizacao; }
    public int getCategoriaId() { return categoriaId; }
    public void setCategoriaId(int categoriaId) { this.categoriaId = categoriaId; }

    public String toString() {
        return nome + " (" + quantidade + ")";
    }
}
