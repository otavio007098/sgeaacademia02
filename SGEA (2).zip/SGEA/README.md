# SGEA - Sistema de Gerenciamento de Equipamentos de Academia

Projeto da disciplina de Desenvolvimento para Desktop. A ideia é simples: ajudar uma academia a saber quais equipamentos tem, onde estão, em que estado estão e quando precisam de manutenção.

Feito em Java puro com **AWT** e banco **SQLite** via JDBC (sem Swing e sem framework).

## O que dá pra fazer

- Cadastrar, editar, excluir e buscar equipamentos pelo nome
- Guardar marca, quantidade, data de aquisição, localização e estado (novo, bom, manutenção, quebrado)
- Criar categorias (musculação, cardio, alongamento...) e ligar cada equipamento a uma
- Registrar manutenções realizadas e agendar manutenções preventivas, com responsável
- Ver o histórico de manutenção de cada equipamento
- Gerar relatórios: em manutenção, disponíveis para uso, que precisam de manutenção e geral
- Ao abrir o sistema, um aviso mostra o que está quebrado, em manutenção ou com manutenção agendada vencida

## Como o projeto está organizado

```
src/
├── modelo/   classes de dados (Equipamento, Categoria, Manutencao) e utilitário de datas
├── dao/      conexão com o SQLite e as consultas de cada entidade
└── tela/     janelas AWT e a classe principal
```

O driver fica em `lib/sqlite-jdbc.jar`. O banco é o arquivo `sgea.db`, criado sozinho (com as tabelas) na primeira execução, na pasta de onde você rodar o programa.

## Como rodar

Precisa do JDK 11 ou mais novo (no Mac: `brew install openjdk`). Na raiz do projeto:

```bash
javac -encoding UTF-8 -d out src/modelo/*.java src/dao/*.java src/tela/*.java
```

```bash
java -cp out:lib/sqlite-jdbc.jar tela.TelaPrincipal
```

No Eclipse: importe como projeto Java, marque a pasta `src` como source folder, adicione `lib/sqlite-jdbc.jar` ao Build Path e rode a `TelaPrincipal`.

## Dicas de uso

1. Comece cadastrando uma categoria.
2. Depois cadastre os equipamentos (datas no formato `dd/MM/aaaa`).
3. Selecione um equipamento na lista e clique em **Manutenções** para registrar ou agendar uma.

## Equipe

Otávio Marques Ribeiro, Pedro Daniel, Guilherme, Paulo Henrique e John Wesley.
